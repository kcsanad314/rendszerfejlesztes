import React from 'react'

class Shop extends React.Component {

   render(){
      return (
         <div className="buttons">
            Ship shop hulla HOP         
         </div>
      )
   }

}

export default Shop
